{
    'name': 'Crm extension',
    'version': '16.0.01',
    'author': 'dworldtec',
    'website': 'www.dworldtec.com',
    'depends': ['crm'],
    'data': [
        'views/crm_lead_extension.xml',
    ],
    'installable': True
}